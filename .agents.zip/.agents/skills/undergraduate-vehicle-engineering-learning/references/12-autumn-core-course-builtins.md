# Autumn Core Course Built-in Skeletons

This file embeds a lightweight course skeleton for offline use. It is based on the user's uploaded file names, extracted first-page titles, and undergraduate course table.

Important:
- These are review scaffolds, not full detailed notes.
- Use uploaded materials for exact source extraction, page numbers, original exercise wording, answer keys, or teacher emphasis.
- If a formula, Q&A, or exercise type is not verified from a source file in the current task, present it as a course-level review candidate and mark uncertain items with TODO when necessary.

## 1. 程序设计 / Computer Programming

Mapped course: `24X1108Y 程序设计（全英）`

### Outline
- Introduction
- Variables and simple data types
- Lists
- List operations
- If statements
- Dictionaries
- User input and while loops
- Functions
- Classes

### Core Knowledge Points
- program structure and execution order
- variables, assignment, and data types
- strings, numbers, booleans
- list indexing, slicing, traversal, mutation
- conditional logic and comparison
- dictionary keys and values
- `while` loops and loop control
- function definition, parameters, return values
- class, object, attribute, method

### Formula / Syntax Bank
- assignment: `name = value`
- condition: `if condition:`
- loop: `while condition:`
- function: `def name(parameters):`
- class: `class Name:`
- common containers: `list`, `dict`

### Q&A Directions
- What is the difference between assignment and comparison?
- What is a list and when should it be used?
- What is a dictionary and why is it useful?
- What is the difference between a function parameter and an argument?
- What is a class and how is it different from an object?

### Exercise Types
- predict code output
- fix syntax or indentation errors
- write a small function
- process a list or dictionary
- convert repeated code into a function
- define a simple class and create objects

## 2. 大学物理（一） / University Physics

Mapped course: `X12071 大学物理（双语）（一）`

### Outline
- Kinematics
- Force and Motion
- Work and Energy
- Linear Momentum and Collisions
- Rotations and Rigid Bodies

### Core Knowledge Points
- displacement, velocity, acceleration
- vector motion and components
- Newton's laws
- free-body diagrams
- work, kinetic energy, potential energy
- conservation of mechanical energy
- impulse and momentum
- collisions
- angular displacement, angular velocity, angular acceleration
- torque and rotational dynamics
- moment of inertia

### Formula Bank Candidates
- `v = v0 + at`
- `x = x0 + v0 t + 1/2 a t^2`
- `v^2 = v0^2 + 2a(x - x0)`
- `F = ma`
- `W = F s cos(theta)`
- `K = 1/2 m v^2`
- `U_g = mgh`
- `p = mv`
- `J = Δp`
- `τ = rF sin(theta)`
- `I = Σmr^2`
- `τ = Iα`
- `K_rot = 1/2 Iω^2`

### Q&A Directions
- What is the difference between speed and velocity?
- Why must forces be drawn before applying Newton's second law?
- When can mechanical energy be conserved?
- What is the difference between momentum conservation and energy conservation in collisions?
- Why does moment of inertia depend on mass distribution?

### Exercise Types
- constant-acceleration calculation
- free-body diagram and Newton's second law
- work-energy theorem
- momentum and collision problems
- rotation kinematics and torque

## 3. 电工与电子技术基础

Mapped course: `X205011 电工与电子技术基础（英）`

### Outline
- Introduction to electrical engineering
- Resistive circuits
- Inductance and capacitance
- Transients
- Steady-state sinusoidal analysis
- Logic circuits
- Diodes
- Amplifiers
- Bipolar junction transistors
- Operational amplifiers

### Core Knowledge Points
- voltage, current, power, energy
- Ohm's law
- Kirchhoff's current law and voltage law
- node-voltage method
- resistance combinations
- capacitors and inductors
- RC/RL transient response
- sinusoidal signals and phasors
- impedance and AC power
- logic gates and truth tables
- diode model and circuit state
- amplifier gain
- BJT basic operation
- ideal op-amp assumptions

### Formula Bank Candidates
- `V = IR`
- `P = VI = I^2R = V^2/R`
- KCL: sum of currents at a node equals zero
- KVL: sum of voltages around a loop equals zero
- capacitor: `i = C dv/dt`
- inductor: `v = L di/dt`
- RC time constant: `τ = RC`
- RL time constant: `τ = L/R`
- impedance: `Z_R = R`, `Z_L = jωL`, `Z_C = 1/(jωC)`
- op-amp ideal rules: input current approximately zero; `v+ ≈ v-` under negative feedback

### Q&A Directions
- How do voltage and current reference directions affect signs?
- What is the difference between absorbing and delivering power?
- Why do capacitors resist sudden voltage change?
- Why do inductors resist sudden current change?
- What is a phasor and why is it useful in AC analysis?
- What assumptions are used for ideal op-amp circuits?

### Exercise Types
- circuit variable and power sign questions
- node-voltage equations
- transient RC/RL response
- sinusoidal steady-state and impedance calculation
- logic truth table
- diode state analysis
- amplifier/op-amp circuit equation

## 4. 工程力学1 / Mechanics for Engineers

Mapped course: `MEEN1008W Mechanics for Engineers`

### Outline
- Course introduction and vectors
- Statics of particles
- Rigid bodies
- Equilibrium in 2D and 3D
- Kinematics of particles
- Friction
- Centroids and distributed forces
- Forces in trusses and cables
- Labs: projectile motion, trusses
- Project: equilibrium in 3D

### Core Knowledge Points
- vector components
- force resultants
- particle equilibrium
- moment of a force
- rigid body free-body diagrams
- equilibrium equations
- friction cone and limiting friction
- centroid calculation
- distributed load equivalent force
- truss member force analysis
- projectile motion and particle kinematics

### Formula Bank Candidates
- vector decomposition: `Fx = F cos(theta)`, `Fy = F sin(theta)`
- equilibrium: `ΣF = 0`, `ΣM = 0`
- moment: `M = r × F`
- friction: `F_f ≤ μ_s N`, `F_k = μ_k N`
- centroid: `x_bar = ΣA_i x_i / ΣA_i`
- distributed load resultant: `R = ∫w(x) dx`
- constant-acceleration kinematics formulas

### Q&A Directions
- Why is a free-body diagram the first step in statics?
- What is the difference between a particle and a rigid body model?
- Why can a distributed load be replaced by a resultant force?
- How do method of joints and method of sections differ in truss analysis?

### Exercise Types
- vector resultant
- particle equilibrium
- rigid body equilibrium
- friction problem
- centroid/distributed force calculation
- truss/cable force calculation
- projectile motion lab calculation

## 5. 工程力学2 / Applied Dynamics

Mapped course: `MEEN2002W Applied Dynamics`

### Outline
- Course introduction
- Particle kinematics
- Plane kinematics of rigid bodies
- Plane kinetics of particles
- Kinetics of systems of particles
- Plane kinetics of rigid bodies
- Project and exercise files

### Core Knowledge Points
- particle position, velocity, acceleration
- normal-tangential and polar descriptions when present
- rigid body translation and rotation
- relative motion
- Newton's second law for particles
- work-energy method
- impulse-momentum method
- mass center
- rigid body plane kinetics
- moment of inertia and angular acceleration

### Formula Bank Candidates
- `v = dr/dt`, `a = dv/dt`
- `ΣF = ma`
- `ΣM_G = I_G α`
- work-energy: `T1 + U_1→2 = T2`
- impulse-momentum: `∫F dt = Δ(mv)`
- rigid body kinetic energy: `T = 1/2 m v_G^2 + 1/2 I_G ω^2`
- rolling relation: `v = rω`, `a_t = rα`

### Q&A Directions
- What is the difference between kinematics and kinetics?
- Why does rigid body motion need both translation and rotation?
- When is work-energy easier than force-acceleration?
- What does mass center mean in systems of particles?

### Exercise Types
- particle motion calculation
- relative velocity/acceleration
- rigid body kinematics
- force-acceleration method
- work-energy method
- impulse-momentum method
- rigid body kinetics

## 6. 机械控制工程

Mapped course: `X207010 机械控制工程（英）`

### Outline
- Introduction
- Modeling
- Time-domain analysis
- Frequency response

### Core Knowledge Points
- control system components
- input, output, feedback
- mathematical modeling
- transfer function
- block diagram
- time response
- transient response indicators
- stability concept
- frequency response
- Bode plot interpretation

### Formula Bank Candidates
- transfer function: `G(s) = Y(s) / U(s)`
- first-order response form: `G(s) = K / (Ts + 1)`
- second-order standard form: `G(s) = ω_n^2 / (s^2 + 2ζω_n s + ω_n^2)`
- time-domain indicators: rise time, peak time, overshoot, settling time
- frequency response: evaluate `G(jω)`

### Q&A Directions
- What is feedback and why is it useful?
- What does a transfer function describe?
- What is the difference between time-domain and frequency-domain analysis?
- How do damping ratio and natural frequency affect response?

### Exercise Types
- derive simple transfer function
- draw or simplify block diagram
- identify time-response parameters
- judge stability from response
- interpret Bode/frequency-response features

## 7. 流体力学1 / Mechanics of Fluids 1

Mapped course: `MEEN2001W Mechanics of Fluids 1`

### Outline
- Introductory fluid concepts
- Fluid statics
- Fluid dynamics
- Fluid kinematics
- Conservation laws
- Dimensional analysis
- Internal flow in pipes
- Exercise sets and answers: statics, Bernoulli, continuity, momentum, energy

### Core Knowledge Points
- fluid properties
- pressure and hydrostatics
- buoyancy when present
- flow description
- velocity field and acceleration
- continuity equation
- Bernoulli equation
- momentum equation
- energy equation
- dimensional analysis
- pipe flow, Reynolds number, head loss

### Formula Bank Candidates
- hydrostatic pressure: `p = p0 + ρgh`
- continuity: `A1 V1 = A2 V2` for incompressible steady flow
- Bernoulli: `p/ρg + V^2/(2g) + z = constant`
- Reynolds number: `Re = ρVD/μ`
- momentum equation: `ΣF = ṁ(V_out - V_in)`
- energy equation with pumps/losses
- Darcy-Weisbach: `h_f = f(L/D)(V^2/2g)`

### Q&A Directions
- What is the physical meaning of pressure?
- When can Bernoulli's equation be used?
- What does Reynolds number tell us?
- Why are losses needed in real pipe-flow analysis?

### Exercise Types
- hydrostatic pressure
- Bernoulli application
- continuity calculation
- momentum equation application
- energy equation and head loss
- dimensional analysis
- pipe-flow problem

## 8. 流体力学2 / Mechanics of Fluids 2

Mapped course: `MEEN3005W Mechanics of Fluids 2`

### Outline
- External flow
- Automotive aerodynamics
- Compressible flow
- Compressible flow continuation
- Turbomachinery
- Textbook and solution/study materials

### Core Knowledge Points
- boundary layer and drag
- lift and drag coefficients
- external flow over bodies
- automotive aerodynamic drag
- compressibility and Mach number
- isentropic flow basics when present
- normal shock or compressible-flow relations if present
- turbomachinery energy transfer

### Formula Bank Candidates
- drag: `D = 1/2 ρ V^2 C_D A`
- lift: `L = 1/2 ρ V^2 C_L A`
- Mach number: `Ma = V/a`
- speed of sound: `a = sqrt(kRT)` for ideal gas
- turbomachinery power/energy relations: TODO verify from slides

### Q&A Directions
- Why does aerodynamic drag grow quickly with speed?
- What is the meaning of drag coefficient?
- What changes when flow becomes compressible?
- What is the purpose of turbomachinery in fluid systems?

### Exercise Types
- drag/lift calculation
- automotive aerodynamic force estimation
- Mach number/compressibility recognition
- compressible-flow table use
- turbomachinery energy/power question

## 9. 热力学1 / Thermodynamics 1

Mapped course: `MEEN1009W Thermodynamics 1`

### Outline
- Equation of state
- First law of thermodynamics
- Heat transfer basics
- Energy analysis of closed systems
- Specific heats
- Energy analysis of control volumes
- Module review
- Assignment on dimensional homogeneity and heat transfer through pipe

### Core Knowledge Points
- thermodynamic system and state
- properties and equation of state
- ideal gas model
- heat and work
- first law for closed systems
- internal energy and enthalpy
- specific heat
- control volume
- steady-flow energy equation
- heat transfer basics
- dimensional homogeneity

### Formula Bank Candidates
- ideal gas: `pV = mRT`
- first law closed system: `ΔE = Q - W`
- enthalpy: `h = u + pv`
- specific heat: `du = c_v dT`, `dh = c_p dT`
- steady-flow energy equation: `Qdot - Wdot = mdot[(h2-h1) + (V2^2 - V1^2)/2 + g(z2-z1)]`
- heat transfer rate forms: TODO verify exact course treatment

### Q&A Directions
- What is the difference between heat and temperature?
- Why is work path-dependent?
- What is the difference between closed system and control volume?
- Why is enthalpy useful in flowing systems?

### Exercise Types
- ideal gas state calculation
- first-law energy balance
- closed-system energy analysis
- control-volume energy analysis
- specific heat calculation
- dimensional homogeneity question

## 10. 热力学2 / Thermodynamics 2

Mapped course: `MEEN3001W Thermodynamics 2`

### Outline
- Lecture sequence 1-12
- Entropy balance
- Exergy
- Gas power cycle
- Property tables
- Textbooks, solution manuals, notes, and exercise material

### Core Knowledge Points
- second law concepts
- entropy and entropy balance
- irreversibility
- exergy
- gas power cycles
- cycle efficiency
- property table use
- engineering thermodynamic cycle analysis

### Formula Bank Candidates
- entropy balance: `S_in - S_out + S_gen = ΔS_system`
- exergy concept: maximum useful work relative to environment
- thermal efficiency: `η = W_net / Q_in`
- cycle energy balance formulas: TODO verify exact cycles from slides
- property table interpolation: TODO verify from tables and examples

### Q&A Directions
- Why does entropy help judge process direction?
- What is the meaning of entropy generation?
- What is exergy and why is it different from energy?
- How do gas power cycles convert heat input into net work?

### Exercise Types
- entropy balance
- second-law efficiency/exergy question
- gas power cycle analysis
- property table lookup
- cycle efficiency calculation

## 11. 液压传动 / Hydraulic Transmission

Mapped course: `X2505080Y 液压与气动传动（英）`

### Outline
- Chapter 1-7 lecture files
- Hydraulic Transmission Chapter 1 Lecture 1
- Short-answer material
- Question bank with fill-in, true/false, multiple-choice, Q&A, circuit analysis, and circuit drawing
- Notes file needing confirmation

### Core Knowledge Points
- hydraulic transmission system composition
- hydraulic fluid and pressure
- pumps, motors, cylinders, valves
- flow, pressure, power
- basic hydraulic circuits
- speed control circuits
- pressure control circuits
- direction control circuits
- pneumatic/hydraulic comparison if present
- circuit analysis and circuit drawing

### Formula Bank Candidates
- pressure: `p = F/A`
- flow: `Q = A v`
- hydraulic power: `P = pQ`
- cylinder force: `F = pA`
- actuator speed: `v = Q/A`
- efficiency-adjusted power: TODO verify from slides

### Q&A Directions
- What are the main parts of a hydraulic system?
- Why can hydraulic transmission produce large force?
- What is the relationship between pressure, flow, force, and speed?
- What is the function of a directional control valve?
- How do speed-control and pressure-control circuits differ?

### Exercise Types
- fill-in/true-false/multiple-choice from question bank
- short-answer concept questions
- hydraulic circuit function analysis
- draw or complete hydraulic circuit
- compute pressure, flow, force, speed, or power

## Cross-Course Use Rules

When the user asks for a course without uploading the PDFs:
- Use this built-in skeleton for initial review, but say it is a built-in scaffold.
- Do not claim exact source page numbers.
- Do not quote exact exercise wording unless it was previously extracted and stored.

When the user uploads course materials:
- Use `11-autumn-core-course-index.md` only as a starting index.
- Re-read the actual files for exact exercise extraction, formula verification, and answer checking.
