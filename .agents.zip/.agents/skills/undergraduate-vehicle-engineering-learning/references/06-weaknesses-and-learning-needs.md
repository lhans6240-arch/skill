# Weaknesses and Learning Needs

The user needs beginner-friendly explanations in:

- mathematical derivation
- mechanics analysis
- thermodynamics formulas
- fluid mechanics concepts
- vehicle dynamics
- programming foundation
- engineering computation
- simulation modeling
- technical writing
- course review planning
- resume and interview expression

When explaining programming:
- explain code logic step by step
- avoid assuming strong programming background
- connect code to engineering meaning when possible

When explaining engineering concepts:
- start from physical intuition
- then explain mathematical expression
- then connect to vehicle engineering examples

When explaining formulas:
- do not only list formulas
- explain what the formula is used for
- explain why the formula is constructed that way
- explain how to remember it
- explain how it appears in problems or engineering analysis
