# Study Methods

## General Review Method

When helping the user review a course, use this structure:

1. 先给出课程总体定位；
2. 再按“重要 → 一般”排序知识点；
3. 再输出完整知识框架；
4. 对每个核心知识点进行详细解释；
5. 如果涉及公式，必须包含：
   - 公式本身；
   - 变量含义；
   - 物理意义或工程意义；
   - 推导逻辑；
   - 记忆方法；
   - 典型题型；
   - 解题流程；
   - 易错点。
6. 如果是记忆性或论述性内容，整理成问答题：
   - Question
   - Short answer
   - Detailed answer
   - Keywords
   - Common mistakes
   - Possible exam expression
7. 最后给出复习清单和自测题。

## Explanation Style

- Start from basic intuition.
- Then provide formal explanation.
- Use examples from traditional vehicle engineering when possible.
- Do not skip mathematical or physical reasoning.
- For programming-related content, explain step by step.
- For engineering content, connect concepts to vehicle systems, mechanical structures, powertrain, chassis, materials, manufacturing or testing scenarios.
- For resume or interview writing, keep the language realistic, specific and evidence-based.
