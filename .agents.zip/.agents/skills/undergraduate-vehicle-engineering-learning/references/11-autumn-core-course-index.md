# Autumn Core Course Index

This file records the course index built from the user's uploaded undergraduate course materials under `大学课程/`.

Important:
- This is an index, not detailed review material.
- Files starting with `._` are treated as macOS metadata and ignored.
- Textbook PDFs, solution manuals, answer keys, labs, projects, and notes are auxiliary materials unless the user asks to use them.
- Course mapping is based on folder names, file names, extracted first-page titles, and the user's undergraduate course table.
- Do not infer missing chapters, missing exams, teacher emphasis, grades, or project achievements.

## 1. Identified Courses

| Folder | Identified Course | Evidence | Mapped Undergraduate Course |
|---|---|---|---|
| `程序设计` | Computer Programming / 程序设计 | First pages show `Computer Programming`; files cover variables, lists, dictionaries, loops, functions, classes | `24X1108Y 程序设计（全英）` |
| `大学物理1` | University Physics / 大学物理（一） | First pages show `University Physics`; files cover kinematics, force, work-energy, momentum, rotation | `X12071 大学物理（双语）（一）` |
| `电子电工` | Electrical and Electronic Engineering foundation | Chapter files cover resistive circuits, inductance/capacitance, transients, sinusoidal analysis, logic, diodes, amplifiers, BJT, op-amps | `X205011 电工与电子技术基础（英）` |
| `工程力学1` | MEEN1008W Mechanics for Engineers | First pages show `MEEN1008W: Mechanics for Engineers`; files cover vectors, statics, rigid bodies, equilibrium, friction, centroids, trusses/cables, particle kinematics | `MEEN1008W Mechanics for Engineers` |
| `工程力学2` | MEEN2002W Applied Dynamics | First pages show `MEEN2002W: Applied Dynamics`; files cover particle kinematics, rigid body kinematics, particle kinetics, systems of particles, rigid body kinetics | `MEEN2002W Applied Dynamics` |
| `机械控制工程` | Mechanical Control Engineering | Folder name and chapter files show introduction, modeling, time-domain analysis, frequency response | `X207010 机械控制工程（英）` |
| `流体力学1` | Mechanics of Fluids 1 | Files cover fluid dynamics, fluid kinematics, conservation laws, dimensional analysis, internal pipe flow; includes exercise sets and answers | `MEEN2001W Mechanics of Fluids 1` |
| `流体力学 2` | Mechanics of Fluids 2 | Files cover external flow, automotive aerodynamics, compressible flow, turbomachinery; includes textbook materials | `MEEN3005W Mechanics of Fluids 2` |
| `热力学1` | Thermodynamics 1 | First pages show `Engineering Thermodynamics I`; uploaded lectures cover equation of state, first law, heat transfer basics, closed systems, specific heats, control volume, module review | `MEEN1009W Thermodynamics 1` |
| `热力学 2` | Thermodynamics 2 | First pages show `Engineering Thermodynamics II` for later lectures; files include entropy balance, exergy, gas power cycles, textbooks, tables, notes | `MEEN3001W Thermodynamics 2` |
| `液压传动` | Hydraulic Transmission / Hydraulic and Pneumatic Transmission | Folder name and files show hydraulic transmission chapters, short-answer material, question bank, notes | `X2505080Y 液压与气动传动（英）` |

## 2. Courseware Files by Course

### 程序设计

- `1-Introduction.pdf`
- `2-Variables and simple data types.pdf`
- `3-Lists.pdf`
- `4-list2.pdf`
- `5-if.pdf`
- `6-dictionaries.pdf`
- `7-while.pdf`
- `8-function.pdf`
- `9-classes.pdf`

### 大学物理1

- `1 Kinematics.pdf`
- `2 Force and Motion.pdf`
- `3 Work and Energy.pdf`
- `4 Linear Momentum and Collisions.pdf`
- `5 Rotations and Rigid Bodies.pdf`

### 电子电工

- `Chapter1 Introduction.pdf`
- `Chapter2 Resistive Circuits.pdf`
- `Chapter3  Inductance and Capacitance(1).pdf`
- `Chapter4  Transients.pdf`
- `Chapter5  Steady-State Sinusoidal Analysis.pdf`
- `Chapter7 Logic Circuits.pdf`
- `Chapter8  Diodes.pdf`
- `Chapter9 Amplifiers.pdf`
- `Chapter11 Bipolar Junction Transistors.pdf`
- `Chapter12 Operational Amplifiers.pdf`
- `Answer for chapter 1- chapter 12.pdf` — auxiliary answer file
- `新建 Microsoft Word 文档(3).pdf` — likely exam/exercise file, needs confirmation

### 工程力学1

- `1.pdf` — course introduction and vectors
- `2.pdf` — statics of particles
- `3 Rigid Bodies 1 of 4.pdf`
- `4 Rigid Bodies 2 of 4.pdf`
- `5 Rigid Bodies 3 of 4.pdf`
- `6 Rigid Bodies 4 of 4.pdf`
- `7 Equilibrium in 2D and 3D 1 of 2.pdf`
- `8 Equilibrium in 2D and 3D 2 of 2.pdf`
- `9 Kinematics of Particles 1 of 4.pdf`
- `10 Kinematics of Particles 2 of 4.pdf`
- `11 Kinematics of Particles 3 of 4.pdf`
- `12 Kinematics of Particles 4 of 4.pdf`
- `13 Friction 1 of 1.pdf`
- `14 Centroids and Distributed Forces.pdf`
- `15 Forces in Trusses and Cables 1 of 2.pdf`
- `16 Forces in Trusses and Cables 2 of 2.pdf`
- `MEEN1008W - Lab A.pdf` — projectile motion lab
- `MEEN1008W - Lab B.pdf` — trusses lab
- `MEEN1008W - Project Description.pdf` — project description
- `Vector Mechanics for Engineers Statics and Dynamics by Beer,Johnston,Mazurek,Cornwell,Self.pdf` — textbook
- `Vector Mechanics for Engineers, Statics and Dynamics - Instructor Solution Manual (...).pdf` — solution manual
- `课后习题答案.pdf` — auxiliary answer/material file
- `实验B_桁架实验报告.pdf` — lab report template/material, needs user confirmation before resume use

### 工程力学2

- `1 Introduction-1.pdf`
- `2 particle kinematics 1 of 3.pdf`
- `3 particle kinematics 2 of 3.pdf`
- `4 particle kinematics 3 of 3.pdf`
- `5 Plane kinematics of rigid bodies 1 of 4.pdf`
- `6 Plane kinematics of rigid bodies 2 of 4.pdf`
- `7 Plane kinematics of rigid bodies 3 of 4.pdf`
- `8 Plane kinematics of rigid bodies 4 of 4.pdf`
- `9 Plane kinetics of Particles 1 of 3.pdf`
- `10 Plane kinetics of Particles 2 of 3.pdf`
- `11 Plane kinetics of Particles 3 of 3.pdf`
- `12 Plane kinetics of systems of Particles.pdf`
- `13 Plane kinetics of rigid bodies 1 of 4.pdf`
- `14 Plane kinetics of rigid bodies 2 of 4.pdf`
- `15 Plane kinetics of rigid bodies 3 of 4.pdf`
- `16 Plane kinetics of rigid bodies 4 of 4.pdf`
- `Engineering Mechanics Dynamics (7th Edition) - J_ L_ Meriam, L_ G_ Kraige.pdf` — textbook
- `Group Project Description.pdf` — project description
- `MEEN20030 - Project.pdf` — project file, course code/name needs confirmation
- `习题 1.pdf` — exercise file
- `习题 2.pdf` — exercise file
- `习题二及答案.pdf` — exercise/answer file

### 机械控制工程

- `第1章 绪论-修改1.pdf`
- `第2章 建模-修改1.pdf`
- `第3章时域分析_0_1748246690211.pdf`
- `第6章 Frequency-Response0603.pdf`

### 流体力学1

- `1课件.pdf`
- `2课件.pdf`
- `3 课件Chp03FluidDynamics.pdf`
- `4课件Chp04FluidKinematics.pdf`
- `5 课件Chp05ConservationLaws.pdf`
- `6 课件 Chp07DimensionalAnalysis.pdf`
- `7 课件 Chp08InternalFlowPipes.pdf`
- `习题/Set 1 statistic.pdf`
- `习题/Set 2 - Bernoulli_s Equation and Applications.pdf`
- `习题/Set 3 - The Continuity Equation and Applications.pdf`
- `习题/Set 4 - The Momentum Equation and Applications.pdf`
- `习题/Set 5 - The Energy Equation and Applications.pdf`
- `答案/set1解.pdf`
- `答案/set2解.pdf`
- `答案/set3解.pdf`
- `答案/set4解.pdf`
- `答案/set5解.pdf`

### 流体力学 2

- `Chp 9-External Flow.pdf`
- `Chp 10-AutomotiveAerodynamics.pdf`
- `Chp 11 Compressible Flow-01.pdf`
- `Chp 11Compressible Flow 2.pdf`
- `Chp 12-TurboMachinery.pdf`
- `课本/Fundamentals of Fluid Mechanics.pdf` — textbook
- `课本/Student Solutions Manual and Student Study Guide to Fundamentals of Fluid Mechanics (...).pdf` — solution/study guide
- `课本/我所理解的流体力学-第四次印刷.pdf` — supplementary textbook

### 热力学1

- `6-2024 Spring BrightSpace-Lecture 6-Thermodynamics I.pdf` — equation of state
- `7-2024 Spring BrightSpace-Lecture 7-Thermodynamics I.pdf` — first law of thermodynamics
- `8-2024 Spring BrightSpace-Lecture 8-Thermodynamics I.pdf` — heat transfer basics
- `9-2024 Spring BrightSpace-Lecture 9-Thermodynamics I.pdf` — energy analysis of closed system
- `10-2024 Spring BrightSpace-Lecture 10-Thermodynamics I.pdf` — specific heats
- `11-2024 Spring BrightSpace-Lecture 11-Thermodynamics I.pdf` — energy analysis of control volume
- `12-2024 Spring BrightSpace-Lecture 12-Thermodynamics I.pdf` — module review
- `2024 SpringBrightSpace Assignment 1-Thermodynamics I.pdf` — assignment on dimensional homogeneity / heat transfer through pipe
- `Thermodynamics An Engineering Approach  Ninth Edition (...).pdf` — textbook

### 热力学 2

- `lecture 1.pdf`
- `lecture 2.pdf`
- `lecture 3.pdf`
- `lecture 4.pdf`
- `lecture 5.pdf`
- `lecture 6.pdf` — entropy balance
- `lecture 7.pdf` — exergy
- `lecture 8.pdf` — gas power cycle
- `lecture 9.pdf` — gas power cycle
- `lecture 10.pdf`
- `lecture 11.pdf`
- `lecture 12.pdf`
- `Thermodynamics An Engineering Approach 5th (Yunus Cengel) (Z-Library).pdf` — textbook
- `Thermodynamics An Engineering Approach. Solution (Cengel and Boles) (Z-Library).pdf` — solution manual
- `课本/Thermodynamics An Engineering Approach, 10th Edition (...).pdf` — textbook
- `课本/查表.pdf` — property tables
- `课本/工程热力学（第5版） (沈维道、童钧耕).pdf` — textbook
- `课本/热力学题目.pdf` — exercise material
- `热力学笔记.pdf` — notes, extraction unclear

### 液压传动

- `Chapter 1.pdf`
- `Chapter 2.pdf`
- `Chapter 3.pdf`
- `Chapter 4.pdf`
- `Chapter 5.pdf`
- `Chapter 6.pdf`
- `chapter 7.pdf`
- `Hydraulic Transmission - Chapter 1 - Lecture 1.pdf`
- `简答.pdf` — short-answer material
- `题库1-液压与气压传动填空判断选择问答回路分析绘制回路附答案[37页].pdf` — question bank with answers
- `无标题的笔记本.pdf` — notes, needs confirmation

## 3. Files Needing Confirmation

| File | Reason |
|---|---|
| `电子电工/新建 Microsoft Word 文档(3).pdf` | Content appears exam/exercise-like, but file name is generic. Confirm role. |
| `工程力学1/实验B_桁架实验报告.pdf` | Appears related to truss lab report; confirm whether it is user's own report, template, or sample before career use. |
| `工程力学2/MEEN20030 - Project.pdf` | File appears project-related; course code/name needs confirmation because mapped course is `MEEN2002W Applied Dynamics`. |
| `热力学 2/热力学笔记.pdf` | Text extraction is unclear; confirm whether it is notes, scanned notes, or another material type. |
| `液压传动/无标题的笔记本.pdf` | Generic file name; confirm whether it is notes, exercises, or temporary export. |
| Any missing chapter numbers | Missing chapters cannot be inferred from standard textbooks or online outlines. |

## 4. Unreadable or Partially Extracted Content

Some Chinese text in extracted PDF text is garbled because of PDF encoding. When exact wording matters, reopen the original PDF or use OCR/visual inspection instead of relying only on extracted text.
