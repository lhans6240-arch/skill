# Course Type Processing Rules

Use this file to process uploaded materials by course type. These are generic rules; do not assume a user has studied a specific course unless it appears in their course table or uploaded materials.

## 1. Programming Foundation Courses

Common undergraduate course names:
- 程序设计
- Computer Programming
- Programming Fundamentals
- Engineering Programming

When materials are provided, look for:
- variables and data types
- control flow
- lists, arrays, dictionaries, or other data structures
- loops
- functions
- files or input/output
- classes and objects
- debugging examples

Exercise extraction targets:
- code output questions
- fill-in-the-code questions
- debugging questions
- small programming tasks
- function-writing tasks
- class/object usage tasks

Solution style:
1. explain the task goal in plain language
2. identify variables and data structures
3. trace execution step by step
4. show corrected code when needed
5. explain the output
6. list beginner mistakes

Do not assume advanced computer science content unless the uploaded materials contain it.

## 2. University Physics and Mechanics Foundation Courses

Common undergraduate course names:
- 大学物理
- University Physics
- Mechanics for Engineers
- Applied Dynamics

When materials are provided, look for:
- kinematics
- Newton's laws
- force analysis
- work and energy
- momentum and impulse
- collisions
- rotational motion
- torque and angular momentum
- vibration or oscillation if present

Exercise extraction targets:
- motion graph problems
- free-body diagram problems
- work-energy problems
- momentum conservation problems
- collision classification
- rotational dynamics
- unit conversion and vector decomposition

Formula bank targets:
- kinematic equations
- Newton's second law
- work-energy theorem
- conservation of energy
- impulse-momentum theorem
- momentum conservation
- rotational kinematics
- torque and rotational dynamics
- moment of inertia

Do not infer missing physics chapters from a standard textbook. Use only uploaded files for course-specific coverage.

## 3. Electrical and Electronic Engineering Foundation Courses

Common undergraduate course names:
- 电工与电子技术基础
- Electrical Engineering
- Electronic Engineering
- Circuits and Electronics

When materials are provided, look for:
- circuit variables
- Ohm's law
- Kirchhoff's laws
- resistive circuits
- node voltage method
- mesh current method
- capacitance and inductance
- transient circuits
- sinusoidal steady-state
- phasors and impedance
- logic circuits
- diodes
- amplifiers
- transistors
- operational amplifiers

Exercise extraction targets:
- node voltage and mesh current problems
- resistor power and absorbed/delivered power questions
- RC/RL transient response
- phasor and impedance calculations
- AC power
- logic truth tables
- diode circuit states
- amplifier gain
- transistor operating region
- op-amp circuit equations

Solution style:
1. describe or redraw the circuit when possible
2. define reference directions
3. list known and unknown quantities
4. choose KCL, KVL, node voltage, mesh current, transient model, phasor method, or device model
5. solve step by step
6. state units and sign meaning
7. explain common sign, unit, and assumption mistakes

## 4. Solid Mechanics and Structural Analysis Courses

Common undergraduate course names:
- Solid Mechanics
- Mechanics of Materials
- Vehicle Structural Analysis
- 材料力学
- 结构分析

When materials are provided, look for:
- stress and strain
- axial loading
- torsion
- bending
- shear force and bending moment
- beam deflection
- failure criteria if present
- vehicle structure applications if present

Exercise extraction targets:
- stress/strain calculation
- internal force diagrams
- beam bending problems
- torsion problems
- deflection problems
- factor of safety

Formula bank targets:
- normal stress
- shear stress
- Hooke's law
- axial deformation
- torsion formula
- bending stress
- beam deflection formulas when provided

## 5. Thermodynamics, Fluids, and Engine Courses

Common undergraduate course names:
- Thermodynamics
- Fluid Mechanics
- Mechanics of Fluids
- Computational Fluid Mechanics
- Automotive Engines

When materials are provided, look for:
- properties and state variables
- first law of thermodynamics
- second law if present
- cycles
- heat, work, and efficiency
- fluid statics
- continuity equation
- Bernoulli equation
- momentum equation
- engine cycles and engine performance

Exercise extraction targets:
- energy balance
- cycle efficiency
- pressure/flow calculations
- Bernoulli applications
- engine performance parameters
- heat/work sign convention

Do not add advanced research CFD content unless the user's undergraduate materials explicitly contain it.

## 6. Materials and Manufacturing Courses

Common undergraduate course names:
- Materials
- Automotive Materials
- Manufacturing Technology
- Interchangeability and Technical Measurement
- 机械制造技术基础
- 互换性与技术测量

When materials are provided, look for:
- material properties
- metal and polymer basics
- heat treatment if present
- failure and fatigue if present
- manufacturing processes
- tolerances and fits
- measurement and inspection
- automotive material selection

Exercise extraction targets:
- material comparison
- selection reasoning
- tolerance and fit calculation
- process selection
- failure analysis at undergraduate level

## 7. Design and Vehicle Engineering Core Courses

Common undergraduate course names:
- Engineering Drawing
- Design
- Automotive Design
- Vehicle Structural Analysis
- Automotive Vehicle Dynamics
- Automotive Engines
- Vehicle Construction
- 汽车构造
- 汽车部件设计

When materials are provided, look for:
- system composition
- design constraints
- component function
- drawing or modeling requirements
- vehicle chassis, body, powertrain, engine, or dynamics concepts
- design calculation if present

Exercise extraction targets:
- component function explanation
- comparison questions
- design process questions
- calculation problems
- drawing/modeling tasks
- vehicle system relationship questions

Keep outputs at undergraduate traditional vehicle engineering level. Do not turn course topics into postgraduate research claims.
