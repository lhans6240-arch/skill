# Undergraduate Course Map

## A. General Education Courses / 通识教育课程

| No. | Course Code | Course Name | Credits |
|---|---|---|---|
| 1 | 14TH1101 | 体育（一） | 1 |
| 2 | 64TH1001 | 军事理论 | 2 |
| 3 | T1301061 | 英语（一）-1 | 6 |
| 4 | T1301161 | 英语（一）-2 | 4 |
| 5 | 14TH1102 | 体育（二） | 1 |
| 6 | T1301062 | 英语（二）-1 | 6 |
| 7 | T1301162 | 英语（二）-2 | 4 |
| 8 | 1405417K | 体育（国际交通学院） | 2 |
| 9 | T1301063 | 英语（三）-1 | 3 |
| 10 | T1301163 | 英语（三）-2 | 2 |
| 11 | T1301064 | 英语（四）-1 | 3 |
| 12 | T1301164 | 英语（四）-2 | 2 |

Subtotal: 36 credits.

## B. Disciplinary Foundation Courses / 学科基础课程

| No. | Course Code | Course Name | Credits |
|---|---|---|---|
| 13 | X120121 | 高等数学（双语）（一） | 5 |
| 14 | X120424 | 画法几何与机械制图（双语） | 3.5 |
| 15 | X207080 | 国际工程应用写作（英） | 2 |
| 16 | X120122 | 高等数学（双语）（二） | 5 |
| 17 | X12071 | 大学物理（双语）（一） | 4.5 |
| 18 | X120120 | 线性代数（双语） | 2.5 |
| 19 | X12072 | 大学物理（双语）（二） | 4.5 |
| 20 | X2507130Y | 机械制造技术基础（英） | 2 |
| 21 | 24X1108Y | 程序设计（全英） | 3 |
| 22 | X120125 | 概率论与数理统计（双语） | 3 |
| 23 | X205011 | 电工与电子技术基础（英） | 4 |
| 24 | X250706Y | 互换性与技术测量（英） | 2 |
| 25 | X207010 | 机械控制工程（英） | 2 |
| 26 | X2505080Y | 液压与气动传动（英） | 2.5 |

Subtotal: 45.5 credits.

## C. Professional Development Courses / 专业发展课程

| No. | Course Code | Course Name | Credits |
|---|---|---|---|
| 27 | Z2207010 | 汽车构造（英） | 4.5 |
| 28 | Z2207020 | 系统仿真（英） | 2 |
| 29 | Z2207030 | 汽车电器基础与设计（英） | 2.5 |
| 30 | Z2207040 | 电机控制与电池技术（英） | 2.5 |
| 31 | Z2207050 | 汽车部件设计（英） | 3.5 |
| 32 | Z2207060 | 先进驾驶辅助系统（英） | 2 |
| 33 | Z2207070 | 新能源汽车（英） | 2 |

Subtotal: 19 credits.

Important note:
“先进驾驶辅助系统（英）” is listed as an undergraduate professional development course. Treat it only as part of the undergraduate vehicle engineering curriculum. Do not expand it into research experience.

## D. Joint-Training Engineering Courses / 联合培养课程

| No. | Course Code | Course Name | Credits |
|---|---|---|---|
| 34 | MEEN1008W | Mechanics for Engineers | 5 |
| 35 | MEEN1009W | Thermodynamics 1 | 5 |
| 36 | MEEN2003W | Solid Mechanics 1 | 5 |
| 37 | MEEN2004W | Materials 1 | 5 |
| 38 | MEEN2005W | Design 1 | 5 |
| 39 | MEEN2001W | Mechanics of Fluids 1 | 5 |
| 40 | MEEN2002W | Applied Dynamics | 5 |
| 41 | MEEN3002W | Solid Mechanics 2 | 5 |
| 42 | MEEN3003W | Design 2 | 5 |
| 43 | MEEN3004W | Materials 2 | 5 |
| 44 | MEEN3001W | Thermodynamics 2 | 5 |
| 45 | MEEN3005W | Mechanics of Fluids 2 | 5 |
| 46 | MEEN4004W | Vehicle Structural Analysis | 5 |
| 47 | MEEN4005W | Automotive Materials | 5 |
| 48 | MEEN4006W | Automotive Design | 5 |
| 49 | MEEN4001W | Automotive Engines | 5 |
| 50 | MEEN4002W | Computational Fluid Mechanics | 5 |
| 51 | MEEN4003W | Automotive Vehicle Dynamics | 5 |

Subtotal: 90 credits.

## E. Course Grouping by Knowledge Area

### 1. Mathematics and Basic Science

- 高等数学（双语）（一）
- 高等数学（双语）（二）
- 线性代数（双语）
- 概率论与数理统计（双语）
- 大学物理（双语）（一）
- 大学物理（双语）（二）

### 2. Engineering Drawing and Design

- 画法几何与机械制图（双语）
- Design 1
- Design 2
- Automotive Design
- 汽车部件设计

### 3. Mechanics and Dynamics

- Mechanics for Engineers
- Solid Mechanics 1
- Solid Mechanics 2
- Applied Dynamics
- Automotive Vehicle Dynamics

### 4. Thermodynamics, Fluids and Engines

- Thermodynamics 1
- Thermodynamics 2
- Mechanics of Fluids 1
- Mechanics of Fluids 2
- Computational Fluid Mechanics
- Automotive Engines

### 5. Materials and Manufacturing

- Materials 1
- Materials 2
- Automotive Materials
- 机械制造技术基础（英）
- 互换性与技术测量（英）

### 6. Electrical, Control and New Energy

- 电工与电子技术基础（英）
- 机械控制工程（英）
- 液压与气动传动（英）
- 汽车电器基础与设计（英）
- 电机控制与电池技术（英）
- 新能源汽车（英）

### 7. Vehicle Engineering Core

- 汽车构造（英）
- Vehicle Structural Analysis
- Automotive Design
- Automotive Engines
- Automotive Vehicle Dynamics
- 汽车部件设计（英）
- 先进驾驶辅助系统（英）

### 8. Programming, Simulation and Engineering Communication

- 程序设计（全英）
- 系统仿真（英）
- 国际工程应用写作（英）
