# Core Traditional Vehicle Engineering Knowledge

## 1. Mathematics and Physics Foundation

Related courses:
- 高等数学
- 线性代数
- 概率论与数理统计
- 大学物理

Functions:
- support mechanics analysis
- support vehicle dynamics
- support control theory
- support simulation and numerical computation
- support engineering calculation

## 2. Mechanics Foundation

Related courses:
- Mechanics for Engineers
- Solid Mechanics 1
- Solid Mechanics 2
- Applied Dynamics

Functions:
- force analysis
- stress and strain analysis
- dynamic response
- vibration and motion analysis
- vehicle structural analysis

## 3. Thermodynamics and Fluid Mechanics

Related courses:
- Thermodynamics 1
- Thermodynamics 2
- Mechanics of Fluids 1
- Mechanics of Fluids 2
- Computational Fluid Mechanics
- Automotive Engines

Functions:
- engine working process
- heat transfer and energy conversion
- internal combustion engine analysis
- fluid flow around vehicles
- cooling and power system analysis

## 4. Materials and Manufacturing

Related courses:
- Materials 1
- Materials 2
- Automotive Materials
- 机械制造技术基础
- 互换性与技术测量

Functions:
- material selection
- manufacturing process understanding
- tolerance and measurement
- vehicle component reliability
- lightweight design foundation

## 5. Vehicle Structure and Design

Related courses:
- 汽车构造
- Automotive Design
- Vehicle Structural Analysis
- 汽车部件设计
- 画法几何与机械制图
- Design 1
- Design 2

Functions:
- vehicle system composition
- component design
- structural design
- chassis and body structure understanding
- engineering drawing and design expression

## 6. Powertrain and Engine

Related courses:
- Automotive Engines
- Thermodynamics
- Mechanics of Fluids
- 新能源汽车
- 电机控制与电池技术

Functions:
- engine principles
- powertrain system understanding
- new energy vehicle power system
- battery and motor basics
- energy conversion and efficiency analysis

## 7. Electrical, Control and Simulation

Related courses:
- 电工与电子技术基础
- 机械控制工程
- 汽车电器基础与设计
- 系统仿真
- 程序设计

Functions:
- basic electrical systems
- control system understanding
- simulation modeling
- engineering computation
- vehicle electronic system foundation
