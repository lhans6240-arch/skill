# Material Library Rules

This skill is material-driven. The skill itself stores workflows, boundaries, templates, and processing rules. It should not depend on a built-in courseware library.

## Required User Materials for Course-Specific Work

Ask the user to upload or point to relevant materials when they request course-specific outputs.

Useful material types:
- undergraduate course table
- syllabus or teaching plan
- lecture slides
- textbook table of contents or textbook pages
- homework
- quizzes
- past exams
- answer keys
- lab reports
- course design documents
- project reports
- teacher review notes
- resume or job target materials

## Recommended Material Library Structure

The user may organize materials like this:

```text
materials/
  course-table/
    undergraduate-course-table.md
  courses/
    course-name-1/
      slides/
      textbook/
      homework/
      exams/
      answers/
      projects/
    course-name-2/
      slides/
      textbook/
      homework/
      exams/
      answers/
      projects/
  career/
    resume.md
    target-roles.md
    project-evidence/
```

This structure is recommended, not required. If the user's files are organized differently, adapt to the existing folders.

## Material Availability Levels

### Level 0: No Materials

Allowed:
- generic undergraduate traditional vehicle engineering framework
- generic study strategy
- generic templates
- TODO placeholders
- questions about what to upload

Not allowed:
- courseware-specific exercise extraction
- claims about slide emphasis
- claims about actual exam frequency
- project or resume evidence claims

### Level 1: Course Table Only

Allowed:
- course map
- course relationship analysis
- general review route by course type
- generic job-seeking expression based on course names only

Must mark as TODO:
- concrete project evidence
- actual exam style
- teacher emphasis
- source-specific exercises

### Level 2: Courseware Provided

Allowed:
- courseware index
- chapter outline
- extracted formulas
- extracted exercises
- source-based exercise bank
- source-based formula bank
- source-based review package

Required:
- source file citation
- page or slide number when available
- uncertainty list

### Level 3: Courseware + Homework/Exams/Answers Provided

Allowed:
- stronger high-frequency question type inference
- solved exercise bank
- answer-key comparison
- exam-style self-test
- common mistake analysis

Required:
- distinguish lecture-derived knowledge from exam-derived emphasis
- do not overgeneralize from a small number of files

### Level 4: Courseware + Project/Course Design Evidence Provided

Allowed:
- resume bullets
- interview answers
- job-seeking PPT content
- STAR or engineering project descriptions

Required:
- use only provided evidence
- mark missing data as TODO
- do not invent results, metrics, awards, grades, internships, or research experience

## Missing-Material Response Pattern

When materials are missing, respond with:

1. What can be done now.
2. What cannot be done without materials.
3. What files the user should upload.
4. A TODO-based template if useful.

Example:

```text
I can build a generic review framework now, but I cannot extract your teacher's exercises or build a source-based high-frequency question list until you upload slides, homework, exams, or answer keys.
```

## Source Evidence Rule

For every concrete course-specific claim, record the evidence:

| Claim | Source file | Page / slide | Confidence | Notes |
|---|---|---|---|---|

If no evidence exists, write TODO instead of guessing.
