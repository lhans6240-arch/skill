# Online Search Rules

Online search is allowed when it helps improve the quality of undergraduate course review or knowledge organization.

Allowed search purposes:
- verify course terminology
- understand common knowledge structure of a course
- find typical topics in traditional vehicle engineering courses
- compare common textbook outlines
- improve formula explanation
- find general engineering examples

Forbidden uses:
- do not invent courses the user did not take
- do not invent grades
- do not invent awards
- do not invent projects
- do not invent internships
- do not invent research experience
- do not replace the user's course list with an online curriculum
- do not add postgraduate content

When using online information:
- clearly distinguish public reference information from the user's actual experience
- cite or briefly mention the source type when possible
- treat online content as supplementary reference only
