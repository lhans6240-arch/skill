# Courseware Index and Ingestion Rules

Use this file when the user uploads lecture slides, PDFs, handouts, exercise sheets, answer keys, or exam-style files.

## Core Principle

Build the course index before generating review materials. Do not jump directly into detailed explanation unless the user explicitly asks for detailed review notes, exercise solutions, or an exam review package.

Every extracted item should preserve traceability:
- course folder
- source file
- page number or slide number when available
- visible title or chapter marker
- confidence level

## File Handling Rules

- Ignore files starting with `._` unless the user says they are important. These are often macOS metadata files.
- Keep unknown files in an "Needs confirmation" list.
- If PDF text extraction is garbled, still use the file name, page count, and visible extracted headings when reliable.
- Do not infer missing chapters from online materials or textbook tables of contents.
- Do not invent diagrams, variables, numerical values, answer choices, or teacher comments that are not present in the file.

## Course Index Output

For each identified course, output:

| Course folder | Identified course | Evidence | Mapped undergraduate course | Files | Uncertain files |
|---|---|---|---|---|---|

## Chapter Outline Construction

Build a chapter outline using:
- folder name
- file name
- PDF metadata title if available
- first slide or first page title
- table of contents pages
- chapter headings
- repeated slide headers

Do not treat the outline as complete if:
- chapter numbers are missing
- files are answer keys only
- extraction failed
- a file name is generic, such as "new document"

## Exercise Extraction Rules

Identify candidate exercises from:
- words such as Exercise, Example, Problem, Question, Quiz, Homework, Review, Answer, Test
- numbered tasks such as T1.2 or Q1
- multiple-choice options
- calculation prompts
- code snippets asking for output, completion, debugging, or implementation
- circuit diagrams with requested voltage, current, power, node voltage, equivalent resistance, or transfer behavior
- physics prompts asking for displacement, velocity, acceleration, force, work, energy, momentum, collision result, torque, angular acceleration, or moment of inertia

For every extracted exercise, record:
- original text
- source file
- page or slide number
- related topic
- type
- difficulty
- importance
- whether the answer is present in the courseware
- whether a diagram or missing context needs user confirmation

## Importance Ranking

Rank items as Core / Important / General.

Core:
- appears in chapter title or learning objective
- appears repeatedly
- supports many exercises
- is formula-central or method-central
- is a prerequisite for later chapters
- is likely to appear in exam-style questions

Important:
- appears in examples or exercises
- supports one major topic
- is useful for understanding course logic

General:
- background, motivation, history, optional extension, or low-frequency detail

## Deliverable Modes

Use the smallest deliverable that matches the user's request:

- Course index only: files and course mapping, no review notes.
- Outline only: chapter structure and topic list, no detailed explanation.
- Exercise bank: extracted questions, classification, and optional solutions.
- Formula bank: formulas with meaning, variables, derivation logic, use cases, and mistakes.
- Exam review package: integrated review deliverable with knowledge ranking, formulas, question types, Q&A, and self-test.
