# Course Review Rules

## For Formula-Based Courses

Examples:
- 高等数学
- 线性代数
- 大学物理
- Mechanics
- Solid Mechanics
- Thermodynamics
- Fluid Mechanics
- Vehicle Dynamics

Required output:
1. concept explanation
2. formula
3. variable explanation
4. derivation logic
5. physical meaning
6. engineering meaning
7. memory method
8. typical problem type
9. solution steps
10. common mistakes

## For Design and Engineering Courses

Examples:
- 画法几何与机械制图
- Design 1
- Design 2
- Automotive Design
- 汽车部件设计
- Vehicle Structural Analysis

Required output:
1. design object
2. design constraints
3. design process
4. engineering standards if known
5. typical drawings or models
6. common design errors
7. relation to vehicle engineering practice

## For Memory-Based Courses

Examples:
- 汽车构造
- 汽车电器基础与设计
- 新能源汽车
- Automotive Materials

Required output:
1. concept map
2. Q&A list
3. keyword summary
4. comparison table
5. common exam expressions

## For Engineering Communication Courses

Examples:
- 国际工程应用写作
- 英语课程

Required output:
1. writing scenario
2. structure template
3. useful expressions
4. common mistakes
5. example paragraphs

## For Uploaded Courseware

Examples:
- PDF lecture slides
- exercise sheets
- answer keys
- exam-style PDFs
- course handouts

Required process:
1. build a courseware index first
2. map courseware to the undergraduate course table
3. build a chapter outline from file names and slide headings
4. extract important exercises with source file and page or slide number
5. classify exercises by concept, formula, type, difficulty, and importance
6. solve exercises step by step only when requested
7. build a reusable exercise bank
8. build a reusable formula bank for formula-based courses
9. build an exam review package when requested
10. list files that need user confirmation

Required exam review package:
1. 知识点排列
2. 知识点重要性排序
3. 知识框架
4. 核心概念解释
5. 公式总结
6. 高频题型
7. 易错点
8. 记忆性问答
9. 自测题

Traceability rule:
Every extracted exercise, formula, and high-priority knowledge point should cite the source file and page or slide number when available. If the source is unclear, mark it as TODO instead of inventing evidence.
