# Exam Review Package Rules

Use this file when building exam-oriented outputs from undergraduate courseware.

## Required Package Structure

The exam review package should include:

1. 知识点排列
2. 知识点重要性排序
3. 知识框架
4. 核心概念解释
5. 公式总结
6. 高频题型
7. 易错点
8. 记忆性问答
9. 自测题

## 1. 知识点排列

Arrange knowledge points by course logic:
- prerequisite concepts first
- chapter order second
- problem-solving dependency third
- engineering application last

For formula-based courses, order should usually be:
concept -> model -> formula -> condition -> application -> problem type.

For programming courses, order should usually be:
data type -> control flow -> data structure -> function -> object-oriented concept -> debugging and application.

## 2. 知识点重要性排序

Use three levels:

| Level | Meaning | Typical evidence |
|---|---|---|
| Core Must-Know | Must understand and be able to solve problems | chapter title, repeated formulas, many exercises, answer key focus |
| Important to Master | Should understand and apply | examples, secondary formulas, common comparisons |
| General Understanding | Know the meaning and recognize it | background, introduction, low-frequency detail |

## 3. 知识框架

Output a hierarchical framework:
- Course
- Module
- Chapter
- Knowledge point
- Formula or method
- Typical exercise
- Common mistake

## 4. 核心概念解释

For each core concept:
1. intuitive explanation
2. formal definition
3. why it matters in this course
4. related formula or method
5. typical problem appearance
6. beginner misunderstanding

## 5. 公式总结

For every major formula:
1. formula
2. variables
3. units or dimensions
4. physical or engineering meaning
5. derivation logic
6. use conditions
7. typical exercise pattern
8. memory method
9. common mistakes

## 6. 高频题型

For each high-frequency question type:
1. question type name
2. typical prompt wording
3. required knowledge points
4. required formulas or methods
5. solution steps
6. common mistakes
7. one self-test variant

## 7. 易错点

Classify mistakes by:
- concept confusion
- formula misuse
- sign or direction error
- unit error
- missing condition
- wrong diagram interpretation
- programming syntax or logic error
- calculation process error

## 8. 记忆性问答

Use this format:

Question:

Short answer:

Detailed answer:

Keywords:

Common mistakes:

Possible exam expression:

## 9. 自测题

Include several levels:
- basic recognition questions
- formula application questions
- comprehensive calculation or code questions
- explanation questions
- error-correction questions

Do not include answers unless the user asks for an answer key, or unless the output is explicitly a solved self-test set.

## Exercise Solution Standard

When solving a problem:
1. restate the problem
2. identify known and unknown quantities
3. identify the concept or formula
4. explain why this formula or method applies
5. solve step by step
6. give final answer
7. explain common mistakes
8. connect to similar exam questions

If information is missing, write TODO instead of inventing assumptions.
