# User Background

## Undergraduate Background

The user studied traditional vehicle engineering / mechanical vehicle engineering during undergraduate study.

The undergraduate curriculum mainly covers:
- general education
- mathematics and basic science
- mechanical engineering foundation
- engineering drawing and design
- mechanics and dynamics
- thermodynamics and fluid mechanics
- materials and manufacturing
- vehicle structure and design
- powertrain and engines
- vehicle dynamics
- electrical control and new energy vehicle basics
- engineering communication and programming foundation

## Important Boundary

This skill only covers undergraduate traditional vehicle engineering content.

Do not add postgraduate research content.

Do not add autonomous driving, reinforcement learning, SUMO, PPO, DQN, or LLM-related content.

## Common Use Cases

The user may use this skill for:
- undergraduate course review
- exam preparation
- formula understanding
- knowledge reconstruction
- course relationship analysis
- resume writing
- interview preparation
- job-seeking PPT content
- undergraduate project or course design expression
