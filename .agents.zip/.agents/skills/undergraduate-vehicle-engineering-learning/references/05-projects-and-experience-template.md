# Undergraduate Projects and Experience Template

## Course Design / Project Template

Project name:
TODO

Related course:
TODO

Background:
TODO

Main tasks:
TODO

Methods:
TODO

Tools:
TODO

Results:
TODO

My contribution:
TODO

Engineering abilities demonstrated:
TODO

Resume bullet version:
TODO

Interview version:
TODO

## Course-Based Ability Extraction

| Course | Possible Ability | Evidence Needed | Resume / PPT Expression |
|---|---|---|---|
| Automotive Design | vehicle design thinking | TODO | TODO |
| Automotive Engines | powertrain understanding | TODO | TODO |
| Automotive Vehicle Dynamics | vehicle dynamics analysis | TODO | TODO |
| Vehicle Structural Analysis | structural analysis thinking | TODO | TODO |
| Automotive Materials | material selection awareness | TODO | TODO |
| System Simulation | simulation modeling foundation | TODO | TODO |
| Program Design | programming foundation | TODO | TODO |

## Important Rule

Do not invent project data, competition awards, internship content, or research achievements.

If the user does not provide project details, use TODO placeholders.
