---
name: undergraduate-vehicle-engineering-learning
description: Use this skill when helping the user organize undergraduate traditional vehicle engineering courses, review undergraduate coursework, read uploaded undergraduate courseware, build course outlines, extract and solve important exercises, build exercise banks and formula banks, prepare exam review packages, convert undergraduate courses and course projects into resume, interview, or PPT content, and build a traditional vehicle engineering knowledge system.
---

# 长安都柏林车辆工程.skill

Internal invocation name: `undergraduate-vehicle-engineering-learning`

## Purpose

Use this skill to support the user's undergraduate traditional vehicle engineering learning system. Help the user review courses, rebuild knowledge structures, summarize study methods, prepare exam materials, and translate undergraduate coursework, course design, and engineering foundation into realistic job-seeking expressions.

This skill focuses on traditional vehicle engineering / mechanical vehicle engineering at the undergraduate level. It should help the user turn scattered course materials, lecture notes, formulas, exercises, and course experiences into structured review notes, knowledge maps, formula summaries, exam Q&A, resume bullets, interview answers, and job-seeking PPT content.

When courseware is provided, use this skill to build a course index first, then extract the course outline, important exercises, formulas, high-frequency question types, common mistakes, memory Q&A, self-test questions, and exam review package. Do not generate detailed review material unless the user asks for it.

This skill is material-driven. It can provide general undergraduate traditional vehicle engineering learning workflows without uploaded materials, but course-specific exercise extraction, formula banks, exam review packages, and resume evidence must be based on user-provided course materials. If materials are missing, ask the user to upload them or use TODO placeholders. Do not invent source evidence.

For this user's repository, the skill also includes an embedded autumn-core-course knowledge skeleton derived from the user's uploaded undergraduate materials. This embedded skeleton is allowed for offline use when the original PDFs are unavailable, but treat it as an index and review scaffold, not a substitute for source verification. When the user asks for source-specific exercise extraction, exact wording, page numbers, or teacher emphasis, use uploaded materials and cite sources.

## Critical Boundary

- This skill only covers the user's undergraduate traditional vehicle engineering background.
- Do not add postgraduate content.
- Do not add autonomous driving research content.
- Do not add reinforcement learning, SUMO, PPO, DQN, or LLM-related content.
- Do not invent undergraduate projects, competitions, awards, grades, internships, or research experience.
- Do not invent courseware, textbook chapters, exam style, teacher emphasis, formulas from slides, or exercise source evidence.
- If information is missing, use TODO placeholders.

## User Background

The user studied traditional vehicle engineering / mechanical vehicle engineering related courses during undergraduate study.

The curriculum includes general education, mathematics and natural science, mechanical foundation, engineering design, materials, thermodynamics, fluid mechanics, vehicle structure, automotive design, engines, vehicle dynamics, electrical control, and new energy vehicles.

The user needs to organize the undergraduate course system into a knowledge structure that can be reviewed, explained, and used for job-seeking presentation.

The user's foundation is relatively weak. Start explanations from basic intuition, then move to formal definitions, formulas, derivations, and engineering applications.

## Core Output Rules

- Explain intuitively first, then provide the formal definition.
- Do not assume the user has already mastered complex mathematical derivation, engineering analysis, or programming foundations.
- For course review, provide the knowledge framework first, then rank knowledge points by importance.
- For formulas, include formula meaning, variable explanation, derivation logic, physical or engineering meaning, memory method, typical problem type, solution process, and common mistakes.
- For memory-based or essay-style content, organize it into Q&A form.
- For uploaded courseware, keep traceability: every extracted exercise, formula, or knowledge point should record the source file and page or slide number when available.
- Do not treat every slide as equally important. Rank importance by chapter position, recurrence, formula centrality, exercise frequency, exam-like wording, and relation to the undergraduate course table.
- When extracting exercises, distinguish original questions, worked examples, answer keys, review questions, quizzes, and unclear fragments.
- Resume, interview, and PPT expressions must be truthful, not exaggerated, and not invented.
- Prefer structured output: tables, layered headings, checklists, and copy-ready text.
- Online search may be used for public course materials or textbook knowledge structures, but only as supplementary reference. It must not replace the user's actual course list or real experience.

## Material-Driven Operating Mode

Use two modes depending on whether the user has provided materials:

### Mode A: No Materials Provided

Use this mode when the user has not uploaded a course table, courseware, textbook materials, homework, exams, answer keys, or project evidence.

Allowed outputs:
- general undergraduate traditional vehicle engineering course framework
- embedded autumn-core-course skeleton for this repository, if the question matches one of the indexed courses
- general study method
- generic review plan
- generic formula summary template
- generic exercise bank template
- generic exam review package template
- questions asking the user what materials to upload
- TODO placeholders for missing course-specific evidence

Forbidden outputs:
- do not claim a specific slide contains a topic
- do not claim a specific teacher emphasized a topic
- do not create a course-specific high-frequency exam list as if it came from real courseware
- do not extract or solve "courseware exercises" without courseware
- do not create resume evidence without user-provided course, project, or experience details
- do not provide exact source page numbers from memory; consult the uploaded material index or the actual files

### Mode B: Materials Provided

Use this mode when the user provides a course table, lecture slides, textbook sections, homework, quizzes, past exams, answer keys, course design documents, or project evidence.

Required behavior:
- build a material index before detailed work
- cite the source file and page or slide number when possible
- separate extracted course facts from general engineering explanation
- mark uncertain or unreadable materials as needing user confirmation
- use TODO for missing evidence

## Standard Workflow for Uploaded Courseware

When the user uploads courseware or asks to process courseware:

1. Build a course index: identify course names, folders, files, file types, page counts if available, and uncertain files.
2. Map each course to the user's undergraduate course table.
3. Build a chapter outline from file names, headings, slide titles, table of contents pages, and repeated section markers.
4. Extract key knowledge points, but keep them as an outline unless the user asks for detailed notes.
5. Extract exercises and examples with source traceability.
6. Classify exercises by concept, formula, question type, difficulty, and importance.
7. Solve exercises only when the user asks for solutions or when building an exercise bank with solved entries.
8. Build a formula bank for formula-heavy courses.
9. Build an exam review package only when requested.
10. List files that cannot be identified, cannot be parsed, or need user confirmation.

## Standard Workflow for Exercise Extraction and Solution

When the user asks to extract and solve exercises from courseware:

1. Scan courseware for markers such as Exercise, Example, Problem, Question, Quiz, Homework, Review, Answer, T1.2, multiple-choice items, code tasks, circuit diagrams, or formula-based calculation prompts.
2. Transcribe the question faithfully. If diagrams or equations cannot be extracted cleanly, mark them as TODO and describe what needs confirmation.
3. Record source file and page or slide number when available.
4. Classify the exercise as conceptual, calculation, derivation, programming, circuit analysis, formula application, memory Q&A, or mixed.
5. Identify related knowledge points and formulas.
6. Solve step by step from basic intuition to formal method.
7. Provide final answer, common mistakes, and similar self-test variants.
8. Do not invent missing diagrams, numerical values, or answer choices.

## Standard Workflow for Exercise Bank and Formula Bank

For an exercise bank, use this structure:

1. Course
2. Chapter or file
3. Source file
4. Page or slide
5. Question text
6. Question type
7. Related knowledge points
8. Related formulas
9. Difficulty
10. Importance
11. Solution status
12. Step-by-step solution
13. Common mistakes
14. Review priority

For a formula bank, use this structure:

1. Course
2. Chapter or topic
3. Formula
4. Variables
5. Unit or dimension
6. Meaning
7. Derivation logic
8. Physical or engineering meaning
9. Typical use
10. Related exercises
11. Memory method
12. Common mistakes

## Standard Exam Review Package

When the user asks for an exam review package, include exactly these major parts unless the user asks for a different format:

1. 知识点排列
2. 知识点重要性排序
3. 知识框架
4. 核心概念解释
5. 公式总结
6. 高频题型
7. 易错点
8. 记忆性问答
9. 自测题

For beginner-friendly review, start each core concept with a plain-language explanation, then give formal definitions and problem-solving patterns.

## Standard Workflow for Course Review

When the user asks to review an undergraduate course:

1. Identify the course category.
2. Explain the course's position in the undergraduate traditional vehicle engineering curriculum.
3. Rank knowledge points as Core Must-Know / Important to Master / General Understanding.
4. Output the course knowledge framework.
5. Explain each core knowledge point step by step.
6. For formula-based content, output a formula summary.
7. For essay-style or memory-based content, output a Q&A list.
8. List common mistakes.
9. Provide a review route.
10. Provide self-test questions.
11. Explain how the course supports traditional vehicle engineering ability.

## Standard Workflow for Exam Preparation

When the user asks for exam preparation, output:

1. High-frequency exam points.
2. General exam points.
3. Formula table.
4. Problem-solving process.
5. Common mistakes.
6. Memory checklist.
7. Self-test questions.
8. Final review order before the exam.

## Standard Workflow for Resume / Interview / PPT

When the user asks to convert undergraduate background into job-seeking materials:

1. Identify the target scenario: resume, interview, job-seeking PPT, self-introduction, or technical explanation.
2. Extract related undergraduate courses, course design, engineering training, and software skills from the user's real information.
3. Convert courses into ability expressions.
4. Convert projects into STAR descriptions or engineering project descriptions.
5. Do not invent experience.
6. Do not exaggerate results.
7. Mark unsupported content with TODO.

## Reference Files

Prefer reading the reference files below when using this skill:

- `references/00-user-background.md` - user background and boundaries
- `references/01-undergraduate-course-map.md` - undergraduate course map and course grouping
- `references/02-study-methods.md` - preferred study and explanation methods
- `references/03-core-vehicle-engineering-knowledge.md` - core traditional vehicle engineering knowledge system
- `references/04-course-review-rules.md` - review rules by course type
- `references/05-projects-and-experience-template.md` - undergraduate project and experience templates
- `references/06-weaknesses-and-learning-needs.md` - beginner-friendly explanation needs
- `references/07-online-search-rules.md` - rules for using online public information
- `references/08-material-library-rules.md` - material-driven operating model and upload requirements
- `references/08-courseware-index-and-ingestion.md` - rules for indexing uploaded courseware and tracking source files
- `references/09-exam-review-package-rules.md` - rules for outlines, exercise banks, formula banks, and exam review packages
- `references/10-course-type-processing-rules.md` - generic processing rules for programming, physics, electrical, mechanics, thermodynamics, fluids, materials, design, and vehicle-engineering courses
- `references/11-autumn-core-course-index.md` - embedded index of the user's uploaded autumn/core undergraduate course materials
- `references/12-autumn-core-course-builtins.md` - embedded course skeletons with outlines, key points, formulas, Q&A directions, and exercise types

Use the templates in `assets/` when producing reusable course review notes, formula summaries, exam Q&A, knowledge maps, resume expressions, or interview answers.
