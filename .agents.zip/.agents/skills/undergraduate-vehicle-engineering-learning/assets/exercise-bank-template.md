# Exercise Bank Template

| ID | Course | Chapter / Topic | Source File | Page / Slide | Question Type | Knowledge Points | Related Formulas | Difficulty | Importance | Solution Status |
|---|---|---|---|---|---|---|---|---|---|---|

## Exercise Entry

ID:

Course:

Source:

Page / slide:

Original question:

Source confidence:

Missing context:

Question type:

Related knowledge points:

Related formulas:

Known information:

Unknown target:

Solution steps:

Final answer:

Common mistakes:

Similar self-test:
