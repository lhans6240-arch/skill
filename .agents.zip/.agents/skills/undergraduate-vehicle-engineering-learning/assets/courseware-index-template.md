# Courseware Index Template

## 0. Material Availability

| Material Type | Provided? | Location | Notes |
|---|---|---|---|
| Undergraduate course table | TODO | TODO | TODO |
| Lecture slides | TODO | TODO | TODO |
| Textbook materials | TODO | TODO | TODO |
| Homework / exercises | TODO | TODO | TODO |
| Past exams / quizzes | TODO | TODO | TODO |
| Answer keys | TODO | TODO | TODO |
| Course design / project evidence | TODO | TODO | TODO |

## 1. Identified Courses

| Course Folder | Identified Course | Evidence | Mapped Undergraduate Course | Confidence |
|---|---|---|---|---|

## 2. Courseware Files

| Course | File | File Type | Pages / Slides | Detected Title | Role | Notes |
|---|---|---|---|---|---|---|

## 3. Uncertain Files

| File | Why Uncertain | Needed Confirmation |
|---|---|---|

## 4. Initial Chapter Outline

| Course | Chapter / Topic | Source File | Evidence |
|---|---|---|---|

## 5. Missing Materials

| Needed Material | Why Needed | What Can Be Done Without It |
|---|---|---|
