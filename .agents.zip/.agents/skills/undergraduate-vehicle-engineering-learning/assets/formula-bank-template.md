# Formula Bank Template

| ID | Course | Chapter / Topic | Formula | Variables | Units / Dimensions | Meaning | Derivation Logic | Typical Use | Common Mistakes |
|---|---|---|---|---|---|---|---|---|---|

## Formula Entry

Formula:

Course / topic:

Variables:

Units / dimensions:

Plain-language meaning:

Formal meaning:

Derivation logic:

Physical / engineering meaning:

Typical exercise type:

Memory method:

Common mistakes:

Related source files:

Missing evidence / TODO:
