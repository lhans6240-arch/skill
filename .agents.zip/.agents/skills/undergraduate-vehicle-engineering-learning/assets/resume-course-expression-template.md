# Resume Course Expression Template

## Target Role

TODO

## Relevant Undergraduate Courses

TODO

## Ability Extraction

| Course / Experience | Ability | Evidence | Resume Expression |
|---|---|---|---|

## Resume Bullet Version

TODO

## PPT Version

TODO

## Interview Version

TODO

Important:
Do not exaggerate or invent data.
