Question:

Short answer:

Detailed answer:

Keywords:

Common mistakes:

Possible exam expression:
