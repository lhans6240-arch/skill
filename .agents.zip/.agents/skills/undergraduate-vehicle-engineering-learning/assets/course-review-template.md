# Course Review Template

## 1. Course Position

## 2. Importance Ranking

| Level | Knowledge Points | Reason |
|---|---|---|
| Core | TODO | TODO |
| Important | TODO | TODO |
| General | TODO | TODO |

## 3. Knowledge Framework

## 4. Detailed Explanation

## 5. Formula Summary

## 6. Common Mistakes

## 7. Exam Questions

## 8. Review Checklist

## 9. Engineering Application in Traditional Vehicle Engineering
