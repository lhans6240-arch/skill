| Formula | Meaning | Variables | Derivation Logic | Physical / Engineering Meaning | Memory Method | Typical Use | Common Mistakes |
|---|---|---|---|---|---|---|---|
