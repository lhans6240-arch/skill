# Material Upload Checklist Template

## Goal

What do you want to build?

- course index
- course outline
- exercise bank
- solved exercise bank
- formula bank
- exam review package
- resume / interview / PPT expression

## Required Materials

| Material | Required For | Provided? | File / Folder | Notes |
|---|---|---|---|---|
| Undergraduate course table | course mapping | TODO | TODO | TODO |
| Syllabus / teaching plan | course scope | TODO | TODO | TODO |
| Lecture slides | outline, formulas, concepts | TODO | TODO | TODO |
| Textbook table of contents or pages | supplementary structure | TODO | TODO | TODO |
| Homework / exercise sheets | exercise bank | TODO | TODO | TODO |
| Past exams / quizzes | high-frequency question types | TODO | TODO | TODO |
| Answer keys | solution checking | TODO | TODO | TODO |
| Course design / project documents | resume/interview/PPT evidence | TODO | TODO | TODO |
| Target role / job description | career expression | TODO | TODO | TODO |

## Missing-Material Decision

If a required material is missing:

1. Continue with a generic framework only.
2. Mark missing evidence as TODO.
3. Ask the user to upload the missing material.
4. Do not invent course-specific claims.
