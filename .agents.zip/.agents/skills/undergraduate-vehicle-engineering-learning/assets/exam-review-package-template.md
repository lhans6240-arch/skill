# Exam Review Package Template

## 0. Source Materials and Limits

| Material | Provided? | Source Location | How It Is Used |
|---|---|---|---|

Missing materials / TODO:

## 1. 知识点排列

## 2. 知识点重要性排序

| Level | Knowledge Points | Reason | Source Evidence |
|---|---|---|---|
| Core Must-Know | TODO | TODO | TODO |
| Important to Master | TODO | TODO | TODO |
| General Understanding | TODO | TODO | TODO |

## 3. 知识框架

## 4. 核心概念解释

| Concept | Intuitive Explanation | Formal Explanation | Typical Use | Common Misunderstanding |
|---|---|---|---|---|

## 5. 公式总结

| Formula | Variables | Meaning | Use Conditions | Typical Question Type | Common Mistakes |
|---|---|---|---|---|---|

## 6. 高频题型

| Question Type | Typical Prompt | Required Knowledge | Solution Steps | Common Mistakes |
|---|---|---|---|---|

## 7. 易错点

## 8. 记忆性问答

Question:

Short answer:

Detailed answer:

Keywords:

Common mistakes:

Possible exam expression:

## 9. 自测题

### Basic

### Formula / Method Application

### Comprehensive

### Error Correction
