Question:

Answer structure:

Suggested answer:

Technical details:

Evidence from undergraduate courses or projects:

Risk points:

How to avoid exaggeration:
